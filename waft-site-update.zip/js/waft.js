/**
 * WAFT — 共通スクリプト
 * 対境界線広域干渉及び超領域的表現開発機構
 */

(function () {
  'use strict';

  // ─── ノイズ・スキャンライン div を生成 ───
  const noiseEl = document.createElement('div');
  noiseEl.id = 'waft-noise';
  document.body.appendChild(noiseEl);

  const scanEl = document.createElement('div');
  scanEl.id = 'waft-scanlines';
  document.body.appendChild(scanEl);

  // ─── カスタムカーソル ───
  const cursor = document.createElement('div');
  cursor.id = 'waft-cursor';
  document.body.appendChild(cursor);

  let mx = -100, my = -100;
  let cx = -100, cy = -100;

  document.addEventListener('mousemove', e => {
    mx = e.clientX;
    my = e.clientY;
  });

  document.addEventListener('mouseenter', () => { cursor.style.opacity = '0.5'; });
  document.addEventListener('mouseleave', () => { cursor.style.opacity = '0'; });

  // ※ 後から表示される要素（data.js が作るリンク等）にも効くよう、イベント委譲で処理する
  const HOVER_SEL = 'a, button, [data-hover]';
  document.addEventListener('mouseover', e => {
    if (e.target.closest && e.target.closest(HOVER_SEL)) cursor.classList.add('expanded');
  });
  document.addEventListener('mouseout', e => {
    const to = e.relatedTarget;
    if (!(to && to.closest && to.closest(HOVER_SEL))) cursor.classList.remove('expanded');
  });

  function animateCursor() {
    cx += (mx - cx) * 0.12;
    cy += (my - cy) * 0.12;
    cursor.style.left = cx + 'px';
    cursor.style.top = cy + 'px';
    requestAnimationFrame(animateCursor);
  }
  animateCursor();

  // ─── 干渉ライン ───
  const line = document.createElement('div');
  line.className = 'interference-line';
  document.body.appendChild(line);

  function triggerInterference() {
    line.style.animationPlayState = 'running';
    line.style.opacity = '1';
    setTimeout(() => {
      line.style.animationPlayState = 'paused';
      line.style.opacity = '0';
    }, 4000);
    // 次回：ランダムな間隔（30〜90秒）
    setTimeout(triggerInterference, 30000 + Math.random() * 60000);
  }
  setTimeout(triggerInterference, 8000 + Math.random() * 20000);

  // ─── 伏字の解除 ───
  document.querySelectorAll('.redacted').forEach(el => {
    el.addEventListener('click', () => el.classList.toggle('revealed'));
  });

  // ─── フェードインオブザーバー ───
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.fade-up').forEach((el, i) => {
    el.style.animationDelay = (i * 0.08) + 's';
    el.style.animationPlayState = 'paused';
    observer.observe(el);
  });

  // ─── ナビゲーション：現在ページのハイライト ───
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    const href = a.getAttribute('href');
    if (href === currentPage || (currentPage === '' && href === 'index.html')) {
      a.classList.add('active');
    }
  });

  // ─── ページ遷移フェード ───
  // イベント委譲：後から表示されたリンクにも効く。Ctrl/⌘クリック等（別タブで開く操作）は邪魔しない。
  document.addEventListener('click', e => {
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const a = e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    const href = a.getAttribute('href');
    if (!href || href.startsWith('#')) return;
    if (/^[a-z][a-z0-9+.\-]*:/i.test(href)) return;   // http:, mailto:, tel: など
    if (a.target === '_blank' || a.hasAttribute('download')) return;
    e.preventDefault();
    document.body.style.transition = 'opacity 0.4s';
    document.body.style.opacity = '0';
    setTimeout(() => { window.location.href = href; }, 400);
  });

  document.body.style.opacity = '0';
  requestAnimationFrame(() => {
    document.body.style.transition = 'opacity 0.6s';
    document.body.style.opacity = '1';
  });

  // ブラウザの「戻る／進む」で復元されたページが透明のまま（真っ白）になるのを防ぐ
  window.addEventListener('pageshow', e => {
    if (e.persisted) {
      document.body.style.transition = 'opacity 0.3s';
      document.body.style.opacity = '1';
    }
  });

  // ─── コンソールへのメッセージ ───
  const msg = [
    '%c対境界線広域干渉及び超領域的表現開発機構',
    'color: #0000FF; font-family: monospace; font-size: 11px;'
  ];
  const msg2 = [
    '%cWAFT / OBSERVER TERMINAL ACTIVE\n> 観測者を認識しました。あなたの閲覧は記録されます。',
    'color: #555; font-family: monospace; font-size: 10px;'
  ];
  console.log(...msg);
  console.log(...msg2);

  // ─── ハンバーガーメニュー ───
  const hamburger = document.getElementById('nav-hamburger');
  const navLinks  = document.getElementById('nav-links');

  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('open');
      navLinks.classList.toggle('open');
      document.body.style.overflow = navLinks.classList.contains('open') ? 'hidden' : '';
    });

    navLinks.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        hamburger.classList.remove('open');
        navLinks.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

})();
