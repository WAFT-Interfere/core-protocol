/**
 * WAFT — データ描画スクリプト
 *
 * data/log.json / data/archive.json / data/events.json を読み込み、
 * 各ページに表示します。
 *
 * ★ 通常このファイルを触る必要はありません。
 *   内容の追加・編集は admin.html（更新ツール）から行ってください。
 */
(function () {
  'use strict';

  // ─── 表示ラベル ───
  var WHO = {
    system: { label: 'SYSTEM',   cls: 'tag-system' },
    aoya:   { label: '青yaヽ跨', cls: 'tag-aoya' },
    misjo:  { label: '三条瞳',   cls: 'tag-misjo' }
  };
  var TYPE_LABEL   = { video: '映像', text: '文章', object: '造形', music: '音楽', other: 'その他' };
  var AUTHOR_LABEL = { aoya: '青yaヽ跨', misjo: '三条瞳', both: '共作' };

  // ─── 小さな道具 ───
  function s(v) { return (v === undefined || v === null) ? '' : String(v); }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null && text !== '') e.textContent = text;
    return e;
  }

  // http(s):// または同じサイト内のファイル名だけを許可（javascript: などは弾く）
  function safeUrl(u) {
    u = s(u).trim();
    if (!u) return '';
    if (/^https?:\/\//i.test(u)) return u;
    if (/^[a-z][a-z0-9+.\-]*:/i.test(u)) return '';
    return u;
  }

  function isExternal(u) { return /^https?:\/\//i.test(u); }

  function hasDate(d) { return /^\d{4}\.\d{2}\.\d{2}/.test(s(d)); }

  // 新しい日付が上。日付の無いものは最後。
  function byDateDesc(a, b) {
    var ha = hasDate(a.date), hb = hasDate(b.date);
    if (ha && !hb) return -1;
    if (!ha && hb) return 1;
    if (!ha && !hb) return 0;
    return s(b.date).localeCompare(s(a.date));
  }

  function byDateAsc(a, b) {
    var ha = hasDate(a.date), hb = hasDate(b.date);
    if (ha && !hb) return -1;
    if (!ha && hb) return 1;
    if (!ha && !hb) return 0;
    return s(a.date).localeCompare(s(b.date));
  }

  function load(name) {
    return fetch('data/' + name + '.json', { cache: 'no-cache' })
      .then(function (res) {
        if (!res.ok) throw new Error('data/' + name + '.json を読み込めません (HTTP ' + res.status + ')');
        return res.text();
      })
      .then(function (txt) {
        var data;
        try { data = JSON.parse(txt); }
        catch (e) { throw new Error('data/' + name + '.json の書式が正しくありません：' + e.message); }
        if (!Array.isArray(data)) throw new Error('data/' + name + '.json は [ ] で囲まれた一覧である必要があります');
        return data;
      });
  }

  function showError(container, err) {
    console.error('[WAFT data]', err);
    if (!container) return;
    var box = el('div', 'data-error');
    box.appendChild(el('div', 'data-error-title', 'DATA LOAD ERROR — データの読み込みに失敗しました'));
    box.appendChild(el('div', 'data-error-body', err && err.message ? err.message : String(err)));
    container.insertBefore(box, container.firstChild);
  }

  function makeLink(url, label, cls) {
    var u = safeUrl(url);
    if (!u) return null;
    var a = el('a', cls, label);
    a.href = u;
    if (isExternal(u)) { a.target = '_blank'; a.rel = 'noopener'; }
    return a;
  }

  // ═══════════════════════════════════════
  //  LOG（活動記録）
  // ═══════════════════════════════════════
  function log() {
    var timeline = document.getElementById('log-timeline');
    var sentinel = document.getElementById('log-sentinel');
    if (!timeline) return;

    load('log').then(function (items) {
      items.slice().sort(byDateDesc).forEach(function (it) {
        var entry = el('div', 'log-entry');

        var dateCol = el('div', 'log-date-col');
        dateCol.appendChild(el('span', 'log-date', s(it.date) || '——'));
        var who = WHO[it.who];
        if (who) {
          var wt = el('span', 'log-tag ' + who.cls, who.label);
          wt.style.marginLeft = '0.75rem';
          dateCol.appendChild(wt);
        }
        entry.appendChild(dateCol);

        var body = el('div', 'log-body-col');
        if (s(it.tag)) {
          var tags = el('div', 'log-tags');
          tags.appendChild(el('span', 'log-tag', s(it.tag)));
          body.appendChild(tags);
        }
        if (s(it.title)) body.appendChild(el('div', 'log-title', s(it.title)));
        if (s(it.text))  body.appendChild(el('div', 'log-text pre', s(it.text)));
        var link = makeLink(it.url, '→ 詳細', 'data-link');
        if (link) body.appendChild(link);
        entry.appendChild(body);

        timeline.insertBefore(entry, sentinel || null);
      });
    }).catch(function (err) { showError(timeline, err); });
  }

  // ═══════════════════════════════════════
  //  ARCHIVE（制作物）
  // ═══════════════════════════════════════
  function archive() {
    var table = document.getElementById('archive-table');
    var emptyState = document.getElementById('empty-state');
    var filterBtns = document.querySelectorAll('.filter-btn');
    if (!table) return;

    function bindFilter() {
      var entries = table.querySelectorAll('.archive-entry');
      filterBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          filterBtns.forEach(function (b) { b.classList.remove('active'); });
          btn.classList.add('active');
          var filter = btn.dataset.filter;
          var visible = 0;
          entries.forEach(function (entry) {
            var show = filter === 'all' || entry.dataset.type === filter;
            entry.style.display = show ? '' : 'none';
            if (show) visible++;
          });
          if (emptyState) emptyState.classList.toggle('visible', visible === 0);
        });
      });
    }

    function placeholder() {
      var d = el('div', 'archive-entry');
      d.dataset.type = 'other';
      d.style.cursor = 'default';
      d.appendChild(el('div', 'entry-date', '——'));
      var main = el('div', 'entry-main');
      main.appendChild(el('div', 'entry-title', '記録待機中'));
      main.appendChild(el('div', 'entry-desc', '干渉の痕跡はここに蓄積される。'));
      d.appendChild(main);
      d.appendChild(el('div', 'entry-author', '——'));
      d.appendChild(el('div', 'entry-tag', '——'));
      return d;
    }

    load('archive').then(function (items) {
      if (items.length === 0) {
        table.appendChild(placeholder());
      }
      items.slice().sort(byDateDesc).forEach(function (it) {
        var u = safeUrl(it.url);
        var row;
        if (u) {
          row = el('a', 'archive-entry');
          row.href = u;
          if (isExternal(u)) { row.target = '_blank'; row.rel = 'noopener'; }
        } else {
          row = el('div', 'archive-entry');
          row.style.cursor = 'default';
        }
        var type = TYPE_LABEL[it.type] ? it.type : 'other';
        row.dataset.type = type;

        row.appendChild(el('div', 'entry-date', s(it.date) || '——'));
        var main = el('div', 'entry-main');
        main.appendChild(el('div', 'entry-title', s(it.title)));
        if (s(it.desc)) main.appendChild(el('div', 'entry-desc pre', s(it.desc)));
        row.appendChild(main);

        var au = AUTHOR_LABEL[it.author];
        row.appendChild(el('div', 'entry-author ' + (au ? it.author : ''), au || '——'));
        row.appendChild(el('div', 'entry-tag', TYPE_LABEL[type]));
        table.appendChild(row);
      });
      bindFilter();
    }).catch(function (err) { showError(table, err); });
  }

  // ═══════════════════════════════════════
  //  EVENTS（拠点開放記録）
  // ═══════════════════════════════════════
  function tagKind(label) {
    if (label.indexOf('三条瞳') !== -1) return 'booth';   // 赤
    if (label.indexOf('青ya') !== -1)   return 'online';  // 青
    return '';
  }

  function events() {
    var list = document.getElementById('event-list');
    var statusText = document.getElementById('events-status-text');
    if (!list) return;

    load('events').then(function (items) {
      var upcoming = items.filter(function (e) { return e.status !== 'past'; }).sort(byDateAsc);
      var past     = items.filter(function (e) { return e.status === 'past'; }).sort(byDateDesc);

      upcoming.concat(past).forEach(function (it) {
        var isPast = it.status === 'past';
        var card = el('div', 'event-card');

        var dateCol = el('div', 'event-date-col');
        dateCol.appendChild(el('div', 'event-date', s(it.date) || '——'));
        dateCol.appendChild(el('span', 'event-status-badge ' + (isPast ? 'past' : 'upcoming'), isPast ? 'PAST' : 'UPCOMING'));
        card.appendChild(dateCol);

        var body = el('div', 'event-body-col');
        body.appendChild(el('div', 'event-name', s(it.name)));
        if (s(it.venue)) body.appendChild(el('div', 'event-venue', s(it.venue)));
        if (s(it.desc))  body.appendChild(el('div', 'event-desc pre', s(it.desc)));
        var tags = Array.isArray(it.tags) ? it.tags : [];
        if (tags.length) {
          var tw = el('div', 'event-tags');
          tags.forEach(function (t) {
            t = s(t).trim();
            if (!t) return;
            var k = tagKind(t);
            tw.appendChild(el('span', 'event-tag' + (k ? ' ' + k : ''), t));
          });
          body.appendChild(tw);
        }
        var link = makeLink(it.url, '詳細を見る →', 'event-link');
        if (link) body.appendChild(link);
        card.appendChild(body);

        list.appendChild(card);
      });

      // ページ上部のステータス表示
      if (statusText) {
        var next = upcoming[0];
        if (next) {
          var name = s(next.name).trim();
          var date = s(next.date).trim();
          if (name && date && date !== '——') statusText.textContent = '次回拠点開放：' + date + ' / ' + name;
          else if (name) statusText.textContent = '次回拠点開放：' + name + '（日程調整中）';
        } else {
          statusText.textContent = '現在、予定されている拠点開放はありません';
        }
      }
    }).catch(function (err) { showError(list, err); });
  }

  // ═══════════════════════════════════════
  //  INDEX（トップの「最終送出記録」）
  // ═══════════════════════════════════════
  function latest() {
    var box = document.getElementById('trans-box');
    var sentinel = document.getElementById('trans-sentinel');
    if (!box) return;

    load('log').then(function (items) {
      var it = items.slice().sort(byDateDesc)[0];
      if (!it) return;
      var a = el('a', 'transmission-entry');
      a.href = 'log.html';
      a.appendChild(el('div', 'trans-date', s(it.date) || '——'));
      var right = document.createElement('div');
      if (s(it.tag)) right.appendChild(el('span', 'trans-tag', s(it.tag)));
      right.appendChild(el('div', 'trans-title', s(it.title)));
      a.appendChild(right);
      box.insertBefore(a, sentinel || null);
    }).catch(function (err) { console.warn('[WAFT data]', err); });
  }

  window.WAFTData = { log: log, archive: archive, events: events, latest: latest };
})();
